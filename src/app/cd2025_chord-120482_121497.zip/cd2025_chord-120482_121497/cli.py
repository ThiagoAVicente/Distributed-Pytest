import threading
import time
import sys
import os
import json
import socket
import pickle
import tkinter as tk
import math

from DHTNode import DHTNode as node
import extra.function as fn

file_path:str = "dht_nodes.json"

# check if DHT.py is running
if not os.path.exists(file_path):
    print(f"[ERROR] {file_path} does not exist.")
    print("Try running: python3 DHT.py")
    exit(1)

# load node file
with open ( file_path, 'r') as fin:
    dht_nodes = json.load(fin)


dht_nodes =sorted(dht_nodes, key=lambda x : x["id"] )

#create socket
sock:socket.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.settimeout(10000)
bind_address = ('localhost', 8000)  # Change the port if needed
sock.bind(bind_address)

fn.check_nodes(sock,dht_nodes)

# draw an chord ring
def show():
    root = tk.Tk()
    root.title("Chord ring")

    canvas = tk.Canvas(root, width=800, height=800, bg="white")
    canvas.pack()

    center_x = 400
    center_y = 400
    radius = 300

    # Draw the circle representing the Chord ring
    canvas.create_oval(center_x - radius, center_y - radius, center_x + radius, center_y + radius, outline="black")

    num_nodes = len(dht_nodes)
    angle_step = 2 * math.pi / num_nodes

    node_positions = {}

    for i, node in enumerate(dht_nodes):
        angle = i * angle_step
        x = center_x + radius * math.cos(angle)
        y = center_y + radius * math.sin(angle)
        node_positions[node["id"]] = (x, y)
        canvas.create_oval(x-10, y-10, x+10, y+10, fill="blue")
        canvas.create_text(x, y-20, text=f"Node {node['id']}", fill="black")

    root.mainloop()

# show all options of the cli
def showOptions():
    print("\n#########################################################################\n")
    print("Available commands:")
    print("quit - Exit the CLI")
    print("help - Show this help message")
    print("list - List all nodes in the DHT")
    print("get <key> - Get the value for the given key from the DHT")
    print("put <key> <value> - Put the key-value pair into the DHT")
    print("clear (all|<node_id>) - Clear the data from all nodes or a specific node")
    print("finger (all|<node_id>) - Show the finger table for all nodes or a specific node")
    print("check - Check the status of all nodes")
    print("store (all|<node_id>) - Show the key store for all nodes or a specific node")
    print("show - shows the chord ring")
    print("\n#########################################################################\n")

# list all nodes dtected
def listNodes():
    print("\nNodes in the DHT:")
    for node in dht_nodes:
        print(f"Node ID: {node['id']}, Address: {node['address']}")
    print()

# get value from key
def getDHT(args):
    key = args[0]
    msg = {"method": "GET", "args": {"key": key, "from": bind_address}}
    node_addr = tuple(dht_nodes[0]["address"])  # Send to the first node in the list
    fn.send(sock, node_addr, msg)
    response, addr = fn.recv(sock)
    print("\n#########################################################################\n")
    if response:
        output = pickle.loads(response)
        if output["method"] == "ACK":
            print(f"Value for key '{key}': {output['args']}")
        else:
            print(f"Failed to get value for key '{key}'")
    else:
        print(f"No response for key '{key}'")

    print("\n#########################################################################\n")

# store an key-value in dht
def putDHT(args):
    key = args[0]
    value = args[1]
    msg = {"method": "PUT", "args": {"key": key, "value": value, "from": bind_address}}
    node_addr = tuple(dht_nodes[0]["address"])  # Send to the first node in the list
    fn.send(sock, node_addr, msg)
    response, addr = fn.recv(sock)
    print("\n#########################################################################\n")
    if response:
        output = pickle.loads(response)
        if output["method"] == "ACK":
            print(f"Successfully put key '{key}' with value '{value}'")
        else:
            print(f"Failed to put key '{key}' with value '{value}'")
    else:
        print(f"No response for key '{key}'")

    print("\n#########################################################################\n")

# get the address of the node with node_id
def getNodeAdd(node_id:int)->list:
    for n in dht_nodes:
        if n["id"] == node_id:
            return n["address"]
    return None

# clear key_store of an node
def clearNode(args):
    target = args[0]
    print("\n#########################################################################\n")
    if target == "all":
        for node in dht_nodes:
            node_addr = tuple(node["address"])
            msg = {"method": "CLEAR"}
            fn.send(sock, node_addr, msg)
            response, addr = fn.recv(sock)
            if response:
                print(f"Cleared node {node['id']}")
            else:
                print(f"Failed to clear node {node['id']}")
    else:
        node_id = int(target)
        node_addr = getNodeAdd(node_id)
        if not node_addr:
            print(f"[ERROR] no node has id: {node_id}")
            return

        node_addr = tuple(node_addr)

        msg = {"method": "CLEAR"}
        fn.send(sock, node_addr, msg)
        response, addr = fn.recv(sock)
        if response:
            print(f"Cleared node {node_id}")
        else:
            print(f"Failed to clear node {node_id}")

    print("\n#########################################################################\n")

# retrieve finger table of an node
def showFingerTable(args):
    target = args[0]
    print("\n#########################################################################\n")
    if target == "all":
        for node in dht_nodes:
            node_addr = tuple(node["address"])
            msg = {"method": "SHOW_FINGER"}
            fn.send(sock, node_addr, msg)
            response, addr = fn.recv(sock)
            if response:
                output = pickle.loads(response)
                print(f"Finger table for node {node['id']}:")
                for idx, entry in enumerate(output['args'], start=1):
                    print(f"  Entry {idx}: ID {entry[0]}, Address {entry[1]}")
            else:
                print(f"Failed to get finger table for node {node['id']}")
    else:
        node_id = int(target)
        n = getNodeAdd(node_id)

        if not n:
            print(f"[ERROR] no node has id: {node_id}")
            return
        n = tuple(n)

        msg = {"method": "SHOW_FINGER"}
        fn.send(sock, n, msg)
        response, addr = fn.recv(sock)
        if response:
            output = pickle.loads(response)
            print(f"Finger table for node {node_id}:")
            for idx, entry in enumerate(output['args'], start=1):
                print(f"  Entry {idx}: ID {entry[0]}, Address {entry[1]}")
        else:
            print(f"Failed to get finger table for node {node_id}")

    print("\n#########################################################################\n")

# retrieve key_store of an node
def showStores(args):
    target = args[0]
    print("\n#########################################################################\n")
    if target == "all":
        for node in dht_nodes:
            node_addr = tuple(node["address"])
            msg = {"method": "SHOW_STORE"}
            fn.send(sock, node_addr, msg)
            response, addr = fn.recv(sock)
            if response:
                output = pickle.loads(response)
                print(f"Stored data for node {node['id']}:")
                for key, value in output['args'].items():
                    print(f"  Key: {key}, Value: {value}")
            else:
                print(f"Failed to get stored data for node {node['id']}")
    else:
        node_id = int(target)
        n = getNodeAdd(node_id)

        if not n:
            print(f"[ERROR] no node has id: {node_id}")
            return
        n = tuple(n)

        msg = {"method": "SHOW_STORE"}
        fn.send(sock, n, msg)
        response, addr = fn.recv(sock)
        if response:
            output = pickle.loads(response)
            print(f"Stored data for node {node_id}:")
            for key, value in output['args'].items():
                print(f"  Key: {key}, Value: {value}")
        else:
            print(f"Failed to get stored data for node {node_id}")

    print("\n#########################################################################\n")

while 2:
    inp:str = input(">> ")

    cmd, args = fn.findMatch(inp)
    if cmd == -1:
        print("[ERROR] invalid input.\n\"help\" for list of options.")
        continue
    match cmd:
        case 0:
            exit(0)
        case 1:
            showOptions()
        case 2:
            listNodes()
        case 3:
            getDHT(args)
        case 4:
            putDHT(args)
        case 5:
            clearNode(args)
        case 6:
            showFingerTable(args)
        case 7:
            fn.check_nodes(sock,dht_nodes)
        case 8:
            showStores(args)
        case 9:
            thread = threading.Thread(target=show)
            thread.daemon = True
            thread.start()
