data = [
    r"quit",                    #0
    r"help",                    #1
    r"list",                    #2
    r"get (\w+)",               #3
    r"put (\w+) (\w+)",         #4
    r"clear (all|\d+)",         #5
    r"finger (all|\d+)",        #6
    r"check",                   #7
    r"store (all|\d+)",         #8
    r"show"                     #9

]
