import pickle
import socket
from time import sleep

from DHTNode import DHTNode as node

def send(sock:socket.socket, address, msg):
    """ Send msg to address. """
    try:
        payload:bytes = pickle.dumps(msg)
        sock.sendto(payload, address)

    except OSError as e:
        print("Socket closed, cannot send message")

def recv(sock:socket.socket) :
    """ Retrieve msg payload and from address."""
    try:
        payload, addr = sock.recvfrom(1024)
    except socket.timeout:
        return None, None

    except OSError as e:
        return None, None


    if len(payload) == 0:
        return None, addr

    #print(f"payload {payload}\naddres {addr}")
    return payload, addr

# check each node
def check_nodes(sock:socket.socket,nodes:dict) -> bool:

    all_responded:bool = True
    for n in nodes:
        n_addr:tuple = tuple( n["address"] )

        n_id:int = n["id"]

        send(sock,n_addr,{"method":"ARE_U_OK"})
        response, addr = recv(sock)

        if response is None or addr[1] != n_addr[1]:
            print(f"Node {n_id} did not respond.")
            all_responded = False
        else:
            print(f"Node {n_id} : OK")
    return all_responded

# check for match of an cmd
def findMatch(inp:str):
    import re
    from extra.commands import data

    for index, pattern in enumerate(data):
        match = re.match(pattern, inp)
        if match:
            return index, match.groups()
    return -1, ()
