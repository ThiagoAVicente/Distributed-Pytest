""" Chord DHT node implementation. """
import socket
import threading
import logging
import pickle
from utils import dht_hash, contains

import math

class FingerTable:
    """Finger Table."""

    def __init__(self, node_id, node_addr, m_bits=10):
        """ Initialize Finger Table."""

        # Save variables
        self.node_id:int = node_id
        self.m_bits:int = m_bits

        # Initialize table
        self.table:list = [None] * m_bits
        self.fill(node_id,node_addr)

    def fill(self, node_id, node_addr):
        """ Fill all entries of finger_table with node_id, node_addr."""
        for i in range( self.m_bits ):
            self.table[i] = (node_id,node_addr)

    def update(self, index, node_id, node_addr):
        """Update index of table with node_id and node_addr."""

        # In the finger table index starts from 1
        self.table[index-1] = (node_id,node_addr)

    def find(self, identification):
        """ Get node address of closest preceding node (in finger table) of identification. """

        # Iterate in reverse order to find the node with the largest node_id that precedes the id
        for i in reversed ( range( 0, self.m_bits) ):
            (finger_id, finger_addr) = self.table[i]

            # Check if finger_id precedes identification
            if contains(finger_id,self.node_id,identification):
                return finger_addr

        return self.table[0][1]

    def refresh(self):
        """ Retrieve finger table entries requiring refresh."""

        # expected output template  (1, 11, ("localhost", 5001))
        #                           (idx:int, node_id:int, addr:tuple )

        temp:list[tuple] = []

        for i in range(self.m_bits):
            idx:int = i+1

            node_id:int = self.node_id + 2**i  # node_id = n + 2^i
            node_id %= 2 ** self.m_bits        # valor máximo é 2^m -1

            node_addr:tuple = self.table[i][1]

            # add to list
            temp.append( (idx,node_id,node_addr) )

        return temp

    def getIdxFromId(self, id):

        """computes the idx of an id based on the distance of that node"""

        # Get distance from current node
        distance:int = id - self.node_id

        # Consider chord ring range
        distance:int = distance % ( 2 ** self.m_bits )

        # Get the range where the distance falls in
        idx:int = round( math.log2(distance) ) + 1

        return idx

    def __repr__(self):
        return str(self.table)

    @property
    def as_list(self):
        """return the finger table as a list of tuples: (identifier, (host, port)).
        NOTE: list index 0 corresponds to finger_table index 1
        """

        print(self.table)
        print("identifier ", self.node_id)
        return self.table

class DHTNode(threading.Thread):
    """ DHT Node Agent. """
    def __init__(self, address, dht_address=None, timeout=3):
        """Constructor

        Parameters:
            address: self's address
            dht_address: address of a node in the DHT
            timeout: impacts how often stabilize algorithm is carried out
        """
        threading.Thread.__init__(self)
        self.done = False
        self.identification = dht_hash(address.__str__())
        self.addr = address  # My address
        self.dht_address = dht_address  # Address of the initial Node
        if dht_address is None:
            self.inside_dht = True
            # I'm my own successor
            self.successor_id = self.identification
            self.successor_addr = address
            self.predecessor_id = None
            self.predecessor_addr = None
        else:
            self.inside_dht = False
            self.successor_id = None
            self.successor_addr = None
            self.predecessor_id = None
            self.predecessor_addr = None

        self.finger_table = FingerTable(self.identification, self.addr)    #TODO create finger_table

        self.keystore = {}  # Where all data is stored
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.settimeout(timeout)
        self.logger = logging.getLogger("Node {}".format(self.identification))

    def send(self, address, msg):
        """ Send msg to address. """
        try:
            payload = pickle.dumps(msg)
            self.logger.debug(f"Sent message to {address}: {msg}")
            self.socket.sendto(payload, address)

        except OSError as e:
            self.logger.error("Socket closed, cannot send message")

    def recv(self):
        """ Retrieve msg payload and from address."""
        try:
            payload, addr = self.socket.recvfrom(1024)
        except socket.timeout:
            return None, None

        except OSError as e:
            return None, None


        if len(payload) == 0:
            return None, addr
        return payload, addr

    def node_join(self, args):
        """Process JOIN_REQ message.

        Parameters:
            args (dict): addr and id of the node trying to join
        """

        self.logger.debug("Node join: %s", args)
        addr = args["addr"]
        identification = args["id"]
        if self.identification == self.successor_id:  # I'm the only node in the DHT
            self.successor_id = identification
            self.successor_addr = addr

            #TODO update finger table
            ##############################################################################
            self.finger_table.fill(self.successor_id,self.successor_addr)
            ##############################################################################

            args = {"successor_id": self.identification, "successor_addr": self.addr}
            self.send(addr, {"method": "JOIN_REP", "args": args})

        elif contains(self.identification, self.successor_id, identification):
            args = {
                "successor_id": self.successor_id,
                "successor_addr": self.successor_addr,
            }
            self.successor_id = identification
            self.successor_addr = addr

            #TODO update finger table
            ##############################################################################
            self.finger_table.update(1,self.successor_id,self.successor_addr)
            ##############################################################################

            self.send(addr, {"method": "JOIN_REP", "args": args})
        else:
            self.logger.debug("Find Successor(%d)", args["id"])
            self.send(self.successor_addr, {"method": "JOIN_REQ", "args": args})
        self.logger.info(self)

    def get_successor(self, args):
        """Process SUCCESSOR message.

        Parameters:
            args (dict): addr and id of the node asking
        """

        self.logger.debug("Get successor: %s", args)

        #TODO Implement processing of SUCCESSOR message
        ##############################################################################
        id_to_find:int = args["id"]
        requester_addr:tuple = args["from"]

        if self.successor_id and contains(self.identification, self.successor_id, id_to_find):
            dic = {"method": "SUCCESSOR_REP",
                    "args": {
                    "req_id": id_to_find,
                    "successor_id": self.successor_id,
                    "successor_addr": self.successor_addr}
                }

            self.logger.debug("Get successor done")
            self.send(requester_addr, dic)

        else:
            next_node_addr = self.finger_table.find(id_to_find)

            # Prevent forwarding back to the same node
            if next_node_addr == self.addr:
                self.logger.error("Loop detected in get_successor, stopping forwarding")
                return

            dic = {"method": "SUCCESSOR",
                    "args": {
                        "id": id_to_find,
                        "from": requester_addr}
                    }

            self.logger.debug("Get successor - Forwarding to %s", next_node_addr)
            self.send(next_node_addr, dic)
        ##############################################################################

    def notify(self, args):
        """Process NOTIFY message.
            Updates predecessor pointers.

        Parameters:
            args (dict): id and addr of the predecessor node
        """

        self.logger.debug("Notify: %s", args)
        if self.predecessor_id is None or contains(self.predecessor_id, self.identification, args["predecessor_id"]):
            self.predecessor_id = args["predecessor_id"]
            self.predecessor_addr = args["predecessor_addr"]
        self.logger.info(self)

    def stabilize(self, from_id, addr):
        """Process STABILIZE protocol.
            Updates all successor pointers.

        Parameters:
            from_id: id of the predecessor of node with address addr
            addr: address of the node sending stabilize message
        """

        self.logger.debug("Stabilize: %s %s", from_id, addr)
        if from_id is not None and contains(
            self.identification, self.successor_id, from_id
        ):
            # Update our successor
            self.successor_id = from_id
            self.successor_addr = addr

            #TODO update finger table
            ##############################################################################
            self.finger_table.update(1,self.successor_id,self.successor_addr)
            ##############################################################################

        # notify successor of our existence, so it can update its predecessor record
        args = {"predecessor_id": self.identification, "predecessor_addr": self.addr}
        self.send(self.successor_addr, {"method": "NOTIFY", "args": args})

        # TODO refresh finger_table of others
        ##############################################################################
        toRefresh:list[tuple] = self.finger_table.refresh()
        for refreshEntry in toRefresh:
            temp_addr:tuple = refreshEntry[2]

            if temp_addr == self.addr : continue

            self.send(temp_addr, {"method": "SUCCESSOR", "args": {"id": refreshEntry[1], "from": self.addr}})
        ##############################################################################

    def put(self, key, value, address):
        """Store value in DHT.

        Parameters:
        key: key of the data
        value: data to be stored
        address: address where to send ack/nack
        """
        key_hash = dht_hash(key)
        self.logger.debug("Put: %s %s", key, key_hash)

        #TODO Replace next code:
        #############################################################################################
        # Se key_hash estiver entre o antecessor e eu (Eu guardo)
        if self.predecessor_id and contains(self.predecessor_id, self.identification, key_hash):
            self.keystore[key] = value               # Armazena a chave pelo hash
            self.send(address, {'method': 'ACK'})         # Confirmação de sucesso

        else:
            # Manda a requisição para o préximo nó
            dic = {"method": "PUT", "args": {"key": key, "value": value, "from": address}}
            # self.send(self.successor_addr,dic)
            node:tuple = self.finger_table.find(key_hash)
            if node == self.addr: return
            self.send(node, dic)
        ####################################################################################################



    def get(self, key, address):
        """Retrieve value from DHT.

        Parameters:
        key: key of the data
        address: address where to send ack/nack
        """
        key_hash = dht_hash(key)
        self.logger.debug("Get: %s %s", key, key_hash)

        #TODO Replace next code:
        ####################################################################################################
        # Se a chave estiver no intervalo entre o antecessor e eu
        if self.predecessor_id and contains(self.predecessor_id, self.identification, key_hash):

            # Retorna o valor
            if key in self.keystore:
                value = self.keystore[key]
                self.send(address, {'method': 'ACK', "args": value})

            # Chave não encontrada
            else:
                self.logger.error("Key Not Found")
                self.send(address, {"method": "NACK"})

        # Procura no interval do proximo nó
        else:
            mssg:dict = {"method": "GET", "args": {"key": key, "from": address}}
            node:tuple = self.finger_table.find(key_hash)
            if node == self.addr: return
            self.send(node,mssg)
        ####################################################################################################

    def run(self):
        self.socket.bind(self.addr)

        # Loop untiln joining the DHT
        while not self.inside_dht:
            join_msg = {
                "method": "JOIN_REQ",
                "args": {"addr": self.addr, "id": self.identification},
            }
            self.send(self.dht_address, join_msg)
            payload, addr = self.recv()
            if payload is not None:
                output = pickle.loads(payload)
                self.logger.debug("O: %s", output)
                if output["method"] == "JOIN_REP":
                    args = output["args"]
                    self.successor_id = args["successor_id"]
                    self.successor_addr = args["successor_addr"]

                    #TODO fill finger table
                    ############################################################
                    self.finger_table.fill(self.successor_id,self.successor_addr)
                    ###########################################################

                    self.inside_dht = True
                    self.logger.info(self)

        while not self.done:
            payload, addr = self.recv()
            if payload is not None:
                output = pickle.loads(payload)
                self.logger.info("O: %s", output)
                if output["method"] == "JOIN_REQ":
                    self.node_join(output["args"])
                elif output["method"] == "NOTIFY":
                    self.notify(output["args"])
                elif output["method"] == "PUT":
                    self.put(
                        output["args"]["key"],
                        output["args"]["value"],
                        output["args"].get("from", addr),
                    )
                elif output["method"] == "GET":
                    self.get(output["args"]["key"], output["args"].get("from", addr))
                elif output["method"] == "PREDECESSOR":
                    # Reply with predecessor id
                    self.send(
                        addr, {"method": "STABILIZE", "args": self.predecessor_id}
                    )
                elif output["method"] == "SUCCESSOR":
                    # Reply with successor of id
                    self.get_successor(output["args"])
                elif output["method"] == "STABILIZE":
                    # Initiate stabilize protocol
                    self.stabilize(output["args"], addr)
                elif output["method"] == "SUCCESSOR_REP":

                    #TODO Implement processing of SUCCESSOR_REP
                    ########################################################
                    args = output["args"]
                    _id:int = args["successor_id"]
                    _addr:tuple = args["successor_addr"]
                    _req_id:int = args["req_id"]

                    idx:int = self.finger_table.getIdxFromId(_req_id)

                    self.finger_table.update(idx,_id,_addr)
                    #######################################################

                ##EXTRA
                elif output["method"] == "ARE_U_OK":
                    self.send(addr,{"method":"OK"})

                elif output["method"] == "CLEAR":
                                    self.clear()
                                    self.send(addr, {"method": "ACK"})

                elif output["method"] == "SHOW_FINGER":
                    self.show_finger(addr)

                elif output["method"] == "SHOW_STORE":
                    self.show_store(addr)

            else:  # timeout occurred, lets run the stabilize algorithm
                # Ask successor for predecessor, to start the stabilize process
                self.send(self.successor_addr, {"method": "PREDECESSOR"})

    def __str__(self):
        return "Node ID: {}; DHT: {}; Successor: {}; Predecessor: {}; FingerTable: {}".format(
            self.identification,
            self.inside_dht,
            self.successor_id,
            self.predecessor_id,
            self.finger_table,
        )

    def __repr__(self):
        return self.__str__()


    ## EXTRA
    def stop(self):
        """Stop the DHT node thread."""
        self.done = True
        self.socket.close()  # Close the socket to unblock the recv call

    def clear(self):
            """Clear all data in the keystore."""
            self.keystore.clear()
            self.logger.info("Keystore cleared")

    def show_finger(self, address):
        """Send the finger table to the requesting address."""
        self.send(address, {"method": "SHOW_FINGER_REP", "args": self.finger_table.as_list})

    def show_store(self, address):
        """Send the finger table to the requesting address."""
        self.send(address, {"method": "SHOW_STORE_REP", "args": self.keystore})
