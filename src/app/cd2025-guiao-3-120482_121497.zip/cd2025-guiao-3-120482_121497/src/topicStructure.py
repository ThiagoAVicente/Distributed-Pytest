import socket
from typing import Optional


class Topic:

    def __init__(self,txt:str) -> None:
        self.txt = txt                  # Topic designation
        self.subtopics:list[Topic] = [] # next topics
        self.subs:list[tuple[socket.socket,any]] = []
        self.value:Optional[str] = None

    def getTxt(self) -> str: return self.txt

    def getSubtopics(self) -> list['Topic']: return self.subtopics

    def getSubs(self) -> list[tuple[socket.socket,any]]:
        # returns a new list with all the subs from this topic
        response: list[tuple[socket.socket, any]] = self.subs.copy()
        return response

    def getValue(self) -> 'str|None': return self.value

    def getTopic(self, topic: str) -> 'Topic':
        # Iterative creation of a topic
        # Ensures that there are always distinct topics

        # ensure format
        parts = [p for p in topic.strip("/").split("/")]
        if topic.startswith("/"):
            parts=["/" + parts[0]] + ["/" + p for p in parts[1:]]
        else:
            parts= [parts[0]] + ["/" + p for p in parts[1:]]

        current = self

        # check if first part is the current node
        if parts[0] == self.txt:
            parts = parts[1:]

        for part in parts:
            part = part.strip().lower()
            # check if the subtopic exists
            found = None
            for subtopic in current.subtopics:
                if subtopic.txt == part:
                    found = subtopic
                    break

            if found is None:
                # create a new subtopic
                new_topic = Topic(part)
                current.subtopics.append(new_topic)
                current = new_topic
                #print(f"Created topic: {new_topic.txt}")

            else:
                current = found

        return current

    def remove(self,topic:str,conn:socket.socket) -> None:
        # should be used on tree root

        t = self.getTopic(topic)

        node:'Topic' = t
        node.__remove(conn)

    def __remove(self,conn:socket.socket) -> None:
        # remove a connection from the node

        for t in self.subs:
            c:socket.socket = t[0]
            if c == conn:
                self.subs.remove(t)

    def getNodesWithValues(self) -> list[str]:
        # returns a list with the txt from every node/topic that contains an value

        response: list['Topic'] = [] if self.value is None else [self.txt]

        for t in self.subtopics:
            temp = list(map( lambda x : self.txt + x,t.getNodesWithValues() ))
            print(self.txt)
            response += temp

        return response
