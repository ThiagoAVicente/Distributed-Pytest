"""Middleware to communicate with PubSub Message Broker."""
from collections.abc import Callable
from enum import Enum
from queue import LifoQueue, Empty
from typing import Any
import socket

from src.broker import Serializer
from src.protocol import CDProto


class MiddlewareType(Enum):
    """Middleware Type."""

    CONSUMER = 1
    PRODUCER = 2

class Queue:
    """Representation of Queue interface for both Consumers and Producers."""

    def __init__(self, topic, _type=MiddlewareType.CONSUMER):
        """Create Queue."""
        self.topic = topic
        self.type = _type

        self._host:str = 'localhost'
        self._port = 5000

        self.queue = LifoQueue()
        self.sock:socket.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        self.sock.connect((self._host, self._port))

        self.serializer = None

    def push(self, value):
        """Sends data to broker."""
        if self.type != MiddlewareType.PRODUCER:
            return # cannot publish

        mssg = {
            "command":"publish",
            "topic":self.topic,
            "value":value
        }

        CDProto.send(self.sock,mssg,self.serializer)

    def pull(self) -> tuple[str, Any]:
        """Receives (topic, data) from broker.

        Should BLOCK the consumer!"""
        while True:
            response, _ = CDProto.recv(self.sock)
            if response is not None:
                cmd = response.get("command")
                if cmd == "newMessage":
                    topic = response.get("topic")
                    value = response.get("value")
                    if topic is not None and value is not None:
                        return topic, value



    def list_topics(self, callback: Callable):
        """Lists all topics available in the broker."""
        CDProto.send(self.sock,{"command":"listTopics"},self.serializer)

        # aguardar resposta do broker
        response, _ = CDProto.recv(self.sock)
        topics = response.get("topics")
        callback(topics)

    def cancel(self):
        """Cancel subscription."""
        mssg = {
            "command":"unsubscribe",
            "topic":self.topic
        }
        CDProto.send(self.sock,mssg,self.serializer)

class JSONQueue(Queue):
    """Queue implementation with JSON based serialization."""

    def __init__(self, topic, _type=MiddlewareType.CONSUMER):
        super().__init__(topic, _type)
        self.serializer = Serializer.JSON

        # subscrever ao topico
        mssg = {
            "command":"subscribe",
            "topic":self.topic
        }
        CDProto.send(self.sock,mssg,self.serializer)



class XMLQueue(Queue):
    """Queue implementation with XML based serialization."""

    def __init__(self, topic, _type=MiddlewareType.CONSUMER):
        super().__init__(topic, _type)
        self.serializer = Serializer.XML

        # subscrever ao topico
        mssg = {
            "command":"subscribe",
            "topic":self.topic
        }
        CDProto.send(self.sock,mssg,self.serializer)



class PickleQueue(Queue):
    """Queue implementation with Pickle based serialization."""

    def __init__(self, topic, _type=MiddlewareType.CONSUMER):
        super().__init__(topic, _type)
        self.serializer = Serializer.PICKLE

        # subscrever ao topico
        mssg = {
            "command":"subscribe",
            "topic":self.topic
        }
        CDProto.send(self.sock,mssg,self.serializer)
