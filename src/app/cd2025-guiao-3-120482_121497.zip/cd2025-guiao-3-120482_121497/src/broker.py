"""Message Broker"""
import enum
from typing import Optional

class Serializer(enum.Enum):
    """Possible message serializers."""
    JSON = 0
    XML = 1
    PICKLE = 2

from pickle import NONE
import socket
from typing import Dict, List, Any, Set, Tuple
from .protocol import CDProto, CDProtoBadFormat

import selectors
from .topicStructure import Topic

class Broker:
    """Implementation of a PubSub Message Broker."""

    def __init__(self):
        """Initialize broker."""
        self.canceled = False
        self._host = "localhost"
        self._port = 5000

        self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._socket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        self._socket.bind((self._host, self._port))
        self._socket.listen(100)
        self._socket.setblocking(False)

        self.subscribers = {}
        self.lastValues = {}

        ## tabelas auxiliares
        self.topicRoot:Topic = Topic("")
        self.subscriber_topic:dict[socket.socket,List[str]] = {}

        self.sel = selectors.DefaultSelector()
        self.sel.register(self._socket, selectors.EVENT_READ, self.accept_connection)


    def list_topics(self) -> List[str]:
        """Returns a list of strings containing all topics containing values."""
        return  self.topicRoot.getNodesWithValues()

    def get_topic(self, topic):
        """Returns the currently stored value in Topic."""
        t:Optional[Topic] = self.topicRoot.getTopic(topic)
        if t is None:
             raise ValueError(f"Topic '{topic}' not found.")
        return t.getValue()

    def put_topic(self, topic, value):
        """Store in Topic the value."""
        t: Topic = self.topicRoot.getTopic(topic)
        t.value = value

    def list_subscriptions(self, topic: str) -> List[Tuple[socket.socket, Serializer]]:
        """Provide list of subscribers to a given Topic."""

        t:Optional[Topic] = self.topicRoot.getTopic(topic)
        if t is None:
             raise ValueError(f"Topic '{topic}' not found.")
        return t.getSubs()

    def subscribe(self, topic: str, address: socket.socket, _format: Serializer = None) -> None:
        """Subscribe to Topic by client in address."""

        t: Topic = self.topicRoot.getTopic(topic)

        t.subs.append((address,_format))

        # atualizar tabela subscritor - topico
        if address in self.subscriber_topic:
            self.subscriber_topic[address].append(topic)
        else:
            self.subscriber_topic[address] = [topic]

    def unsubscribe(self, topic, address) -> None:
        """Unsubscribe to Topic by client in address."""

        # verificar se tópico existe
        t: Optional[Topic] = self.topicRoot.getTopic(topic)
        if t is None: return

        # Remover o assinante do tópico
        t.subs= [
            (addr, fmt) for addr, fmt in t.subs
            if addr != address
        ]

        if address in self.subscriber_topic:
            self.subscriber_topic[address].remove(topic)

            # verificar se já não há subscrições do address
            if len(self.subscriber_topic[address]) == 0:
                del self.subscriber_topic[address]

        return None

    def run(self):
        """Run until canceled."""

        try:
            while not self.canceled:
                events = self.sel.select()
                for key, mask in events:
                    callback = key.data
                    callback(key.fileobj, mask)
        finally:
            self.sel.close()
            self._socket.close()

    def accept_connection(self, sock: socket.socket, mask):
        """Handle new client connection"""
        conn, addr = sock.accept()
        conn.setblocking(False)
        self.sel.register(conn, selectors.EVENT_READ, self.read_message)

    def notify(self,topic:str):

        cons = []
        parts = topic.split("/")
        t: Optional[Topic] = None

        for i in range(1,len(parts)+1):
            target_topic = "/".join(parts[:i])
            t = self.topicRoot.getTopic(target_topic)
            if t is None: continue
            res = t.getSubs()
            cons.extend(res)


        mssg = {
            "command":"newMessage",
            "topic":topic,
            "value":t.value
        }

        for tup in cons:
            sock:socket.socket =tup[0]
            seri:Serializer =   tup[1]

            CDProto.send(sock,mssg,seri)

    def read_message(self, conn: socket.socket, mask):
        """Handle client message"""
        try:
            msg, serializer_type = CDProto.recv(conn)

            if msg is None:
                # remove client
                self.cleanup_subscriber(conn)
                return


            cmd = msg.get("command")
            if cmd == "subscribe":
                topic = msg.get("topic")
                self.subscribe(topic, conn, serializer_type)

            elif cmd == "publish":
                topic = msg.get("topic")
                value = msg.get("value")
                self.put_topic(topic, value)

                # notify clients
                self.notify(topic)

            elif cmd == "unsubscribe":
                topic = msg.get("topic")
                self.unsubscribe(topic, conn)

            elif cmd == "listTopics":
                res:List[str] = self.list_topics()

                mssg = {
                    "command" : "list_REP",
                    "topics" : res
                }

                # enviar resposta
                CDProto.send(conn,mssg,serializer_type)

        except (ConnectionResetError, BrokenPipeError):
            self.cleanup_subscriber(conn)
        except AttributeError:
            return

    def cleanup_subscriber(self, conn: socket.socket):
        """Cleanup subscriber when connection is closed"""
        self.sel.unregister(conn)
        conn.close()
        if conn in self.subscriber_topic:
            topics = self.subscriber_topic[conn]
            for topic in topics:

                t: Optional[Topic] = self.topicRoot.getTopic(topic)
                if t is None: continue

                t.subs = [
                    (addr, fmt) for addr, fmt in t.subs
                    if addr != conn
                ]

            del self.subscriber_topic[conn]
