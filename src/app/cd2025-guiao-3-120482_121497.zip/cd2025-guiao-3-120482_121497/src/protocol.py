"""Protocol for PubSub """
import json
import pickle
import xml.etree.ElementTree as ET
from socket import socket
from typing import Optional, Dict, Any, Tuple
from datetime import datetime
from socket import socket
from .broker import Serializer


def serializer_from_int(value: int) -> Serializer:
    try:
        return Serializer(value)
    except ValueError:
        raise ValueError(f"Invalid serializer value: {value}")


class CDProto:
    """Protocolo de comunicação PubSub"""

    HEADER_SIZE = 3 # 2 bytes para o tamanho +1 byte para serializer


    @classmethod
    def send(cls, conn: socket, data: Dict[str, Any], serializer: Serializer) -> bool:
        """Envia dados serializados através da conexão"""
        try:
            serialized_data = cls.serialize(data, serializer)

            # Monta header: 2 bytes tamanho + 1 byte serializer
            size = len(serialized_data).to_bytes(2, 'big')
            serializer_type = serializer.value.to_bytes(1, 'big')
            header = size + serializer_type
            toSend = header + serialized_data

            sz = len(toSend)
            sent = 0
            while sent < sz:
                sent += conn.send(toSend[sent:])

            return True

        except Exception as e:
            print(f"SEnd error: {e}")
            return False



    @classmethod
    def recv(cls, conn: socket) -> Tuple[Optional[Dict[str, Any]], Optional[Serializer]]:
        """Recebe e desserializa dados da conexão"""
        try:
            # Lê os 3 bytes do header
            header = conn.recv(cls.HEADER_SIZE)
            if len(header) != cls.HEADER_SIZE:
                return None, None

            # Extrai o tamanho dos dados (primeiros 2 bytes)
            size = int.from_bytes(header[:2], 'big')

            # Extrai o serializer (terceiro byte)
            serializer_value = header[2]                 # Extrai o byte como inteiro

            # Converte para a enumeração usando o método from_value
            serializer = serializer_from_int(serializer_value)

            # Lê o corpo da mensagem
            data = b''
            while len(data) < size:
                chunk = conn.recv(min(size - len(data), 4096))  # Lê em chunks
                if not chunk:
                    raise ConnectionError("Conexão fechada durante a leitura")
                data += chunk


            # Desserializa os dados usando o serializer correto
            return cls.deserialize(data, serializer), serializer # Retorna (msg, serializer)

        except Exception as e:
            return None,None



    @classmethod
    def serialize(cls, data: Dict[str, Any], serializer: Serializer) -> bytes:
        """Converte dicionário Python para o formato correspondente pelo serializer"""
        try:
            if serializer == Serializer.JSON:
                return json.dumps(data).encode('utf-8')         # JSON → string → bytes
            elif serializer == Serializer.PICKLE:
                return pickle.dumps(data)                       # Pickle → bytes diretamente
            elif serializer == Serializer.XML:
                root = ET.Element('message')                    # Cria elemento raiz XML
                for key, value in data.items():
                    child = ET.SubElement(root, key)            # Adiciona elementos filhos
                    child.text = str(value)                     # Converte valor para string
                return ET.tostring(root)                        # XML → bytes
            else:
                raise ValueError("Serializer inválido")
        except Exception as e:
            print(f"Serialize error: {e}")
            return b''


    @classmethod
    def deserialize(cls, data: bytes, serializer: Serializer) -> Optional[Dict[str, Any]]:
        """Converte bytes para dicionário Python conforme o serializer"""
        try:
            if serializer == Serializer.JSON:
                return json.loads(data.decode('utf-8'))             # Bytes → string → dicionário
            elif serializer == Serializer.PICKLE:
                return pickle.loads(data)                           # Bytes → dicionário
            elif serializer == Serializer.XML:
                root = ET.fromstring(data.decode('utf-8'))          # Bytes → árvore XML
                return {child.tag: child.text for child in root}    # Converte para dicionário
            else:
                raise ValueError("Serializer inválido")
        except Exception as e:
            print(f"Deserialize error: {e}")
            return None


class CDProtoBadFormat(Exception):
    """Exception when source message is not CDProto."""
    def __init__(self, original_msg: bytes = None):
        self._original = original_msg

    @property
    def original_msg(self) -> str:
        return self._original.decode("utf-8") if self._original else ""
